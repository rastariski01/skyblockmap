#!/bin/bash

for each in `ls *.lang`
do
	if [ "$each" != "en_US.lang" ]; then
		cp en_US.lang $each 
	fi
done